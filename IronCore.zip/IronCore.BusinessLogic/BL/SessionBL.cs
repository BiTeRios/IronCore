﻿using IronCore.BusinessLogic.Core;
using IronCore.BusinessLogic.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IronCore.BusinessLogic
{
    public class SessionBL : UserApi, ISession
    {

    }
}
