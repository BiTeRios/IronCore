﻿using IronCore.BusinessLogic.Interfaces;
using IronCore.Domain.Entities.Coach;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IronCore.BusinessLogic.Core;

namespace IronCore.BusinessLogic.BL
{
    class CoachBL : ICoach
    {
        public void addCoach(CoachCl coach)
        {
            throw new NotImplementedException();
        }

        public bool deleteCoach(int CoachID)
        {
            throw new NotImplementedException();
        }

        public CoachCl getInfoAboutCoach(int CoachID)
        {
            throw new NotImplementedException();
        }

        public void modifyCoach(CoachCl coach)
        {
            throw new NotImplementedException();
        }
    }
}
